<html>
<header class="header black-bg">
              <div class="sidebar-toggle-box">
                  
              </div>
            <!--logo start-->
            
            <!--logo end-->
            <div class="nav notify-row" id="top_menu">-
                <!--  notification start -->
              
                  
            </div>
            <style>
			h1
			{
				
			}
			</style>
            <center> <font size=10><font color="maroon">
            <h1><i class="fa"> 
            GV&CO </i></h1> </font> </font> </center>     
            
        </header>
		</html>