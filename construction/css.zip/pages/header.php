<?php session_start(); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang="en-US" dir="ltr" xmlns="http://www.w3.org/1999/xhtml">
<head>
<!-- <link media="screen, projection" type="text/css" href="css/default.css" rel="stylesheet"> -->
<link media="screen, projection" type="text/css" href="css/style.css" rel="stylesheet">
<link media="screen, projection" type="text/css" href="css/form.css" rel="stylesheet">
<script type="text/javascript" src="js/jquery.js"></script>
<!-- notify -->
<link href="css/notify/jquery_notification.css" type="text/css" rel="stylesheet"/>
<script type="text/javascript" src="js/notify/jquery_notification_v.1.js"></script>
<!-- notify end -->

<!--datepicker -->
<link href="css/datepicker/ui.datepicker.css" type="text/css" rel="stylesheet"/>
<script type="text/javascript" src="js/datepicker/ui.datepicker.js"></script>
<!--datepicker -->

<!-- istar rating kaching kaching! -->
<script src="src/jquery.rateit.js" type="text/javascript"></script>
<link href="src/rateit.css" rel="stylesheet" type="text/css">
<link href="src/bigstars.css" rel="stylesheet" type="text/css">

<!-- istar rating kaching kaching end! -->

<!-- validation -->
<script src="js/validation/jquery.maskedinput.js" type="text/javascript"></script>

<!-- validation -->
